#pragma once
#define FST2VST 1
#include "fst.h"
