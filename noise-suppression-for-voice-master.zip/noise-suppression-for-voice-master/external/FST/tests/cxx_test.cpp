#include "fst/fst.h"

#if defined(_LANGUAGE_C_PLUS_PLUS) || defined(__cplusplus)
extern "C"
#endif
        int main(void);

int main(void) {
    return 0;
}
